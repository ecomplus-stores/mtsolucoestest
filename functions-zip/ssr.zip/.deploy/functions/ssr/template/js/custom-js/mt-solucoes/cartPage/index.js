function addClassOnCotent () {
  document.querySelector('#storefront-app').classList.add('cart-page');
}


export const initCartPage = () => {
  addClassOnCotent ();
}