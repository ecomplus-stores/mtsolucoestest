import '#template/js/'
import './custom-js/pages'
import './custom-js/mt-solucoes/start'